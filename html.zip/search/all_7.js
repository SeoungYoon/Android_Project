var searchData=
[
  ['mainactivity_0',['MainActivity',['../classcom_1_1example_1_1tlqkf_1_1_main_activity.html',1,'com::example::tlqkf']]],
  ['mainactivity_2ejava_1',['MainActivity.java',['../_main_activity_8java.html',1,'']]],
  ['movemain_2',['moveMain',['../classcom_1_1example_1_1tlqkf_1_1_splash_activity.html#a15011135c9d0e80ef61b07b5e94e90bb',1,'com::example::tlqkf::SplashActivity']]]
];
