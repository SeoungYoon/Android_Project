var searchData=
[
  ['registeractivity_0',['RegisterActivity',['../classcom_1_1example_1_1tlqkf_1_1_register_activity.html',1,'com::example::tlqkf']]]
];
