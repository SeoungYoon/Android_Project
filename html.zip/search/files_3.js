var searchData=
[
  ['readme_2emd_0',['README.md',['../_r_e_a_d_m_e_8md.html',1,'']]],
  ['registeractivity_2ejava_1',['RegisterActivity.java',['../_register_activity_8java.html',1,'']]]
];
