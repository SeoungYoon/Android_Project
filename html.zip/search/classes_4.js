var searchData=
[
  ['splashactivity_0',['SplashActivity',['../classcom_1_1example_1_1tlqkf_1_1_splash_activity.html',1,'com::example::tlqkf']]]
];
