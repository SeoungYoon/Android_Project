var indexSectionsWithContent =
{
  0: "abcefjlmorsu구동명및방시실참터",
  1: "elmrs",
  2: "c",
  3: "elmrs",
  4: "aclmou",
  5: "befjl",
  6: "r"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "pages"
};

var indexSectionLabels =
{
  0: "모두",
  1: "클래스",
  2: "네임스페이스들",
  3: "파일들",
  4: "함수",
  5: "변수",
  6: "페이지들"
};

