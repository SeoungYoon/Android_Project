var searchData=
[
  ['mainactivity_0',['MainActivity',['../classcom_1_1example_1_1tlqkf_1_1_main_activity.html',1,'com::example::tlqkf']]]
];
