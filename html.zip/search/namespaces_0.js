var searchData=
[
  ['com_3a_3aexample_3a_3atlqkf_0',['tlqkf',['../namespacecom_1_1example_1_1tlqkf.html',1,'com::example']]]
];
