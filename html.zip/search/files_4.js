var searchData=
[
  ['splashactivity_2ejava_0',['SplashActivity.java',['../_splash_activity_8java.html',1,'']]]
];
