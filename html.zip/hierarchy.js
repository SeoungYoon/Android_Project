var hierarchy =
[
    [ "AppCompatActivity", null, [
      [ "com.example.tlqkf.LoginActivity", "classcom_1_1example_1_1tlqkf_1_1_login_activity.html", null ],
      [ "com.example.tlqkf.MainActivity", "classcom_1_1example_1_1tlqkf_1_1_main_activity.html", null ],
      [ "com.example.tlqkf.RegisterActivity", "classcom_1_1example_1_1tlqkf_1_1_register_activity.html", null ],
      [ "com.example.tlqkf.SplashActivity", "classcom_1_1example_1_1tlqkf_1_1_splash_activity.html", null ]
    ] ],
    [ "com.example.tlqkf.ExampleInstrumentedTest", "classcom_1_1example_1_1tlqkf_1_1_example_instrumented_test.html", null ],
    [ "com.example.tlqkf.ExampleUnitTest", "classcom_1_1example_1_1tlqkf_1_1_example_unit_test.html", null ],
    [ "SensorEventListener", null, [
      [ "com.example.tlqkf.MainActivity", "classcom_1_1example_1_1tlqkf_1_1_main_activity.html", null ]
    ] ]
];