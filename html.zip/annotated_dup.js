var annotated_dup =
[
    [ "com", null, [
      [ "example", null, [
        [ "tlqkf", "namespacecom_1_1example_1_1tlqkf.html", [
          [ "ExampleInstrumentedTest", "classcom_1_1example_1_1tlqkf_1_1_example_instrumented_test.html", "classcom_1_1example_1_1tlqkf_1_1_example_instrumented_test" ],
          [ "ExampleUnitTest", "classcom_1_1example_1_1tlqkf_1_1_example_unit_test.html", "classcom_1_1example_1_1tlqkf_1_1_example_unit_test" ],
          [ "LoginActivity", "classcom_1_1example_1_1tlqkf_1_1_login_activity.html", "classcom_1_1example_1_1tlqkf_1_1_login_activity" ],
          [ "MainActivity", "classcom_1_1example_1_1tlqkf_1_1_main_activity.html", "classcom_1_1example_1_1tlqkf_1_1_main_activity" ],
          [ "RegisterActivity", "classcom_1_1example_1_1tlqkf_1_1_register_activity.html", "classcom_1_1example_1_1tlqkf_1_1_register_activity" ],
          [ "SplashActivity", "classcom_1_1example_1_1tlqkf_1_1_splash_activity.html", "classcom_1_1example_1_1tlqkf_1_1_splash_activity" ]
        ] ]
      ] ]
    ] ]
];