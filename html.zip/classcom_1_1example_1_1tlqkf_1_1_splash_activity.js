var classcom_1_1example_1_1tlqkf_1_1_splash_activity =
[
    [ "moveMain", "classcom_1_1example_1_1tlqkf_1_1_splash_activity.html#a15011135c9d0e80ef61b07b5e94e90bb", null ],
    [ "onCreate", "classcom_1_1example_1_1tlqkf_1_1_splash_activity.html#adb9d8ac0abea5700c69ab4825e3ce9a2", null ]
];