/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var menudata={children:[
{text:"메인 페이지",url:"index.html"},
{text:"관련된 페이지",url:"pages.html"},
{text:"패키지",url:"namespaces.html",children:[
{text:"Package List",url:"namespaces.html"}]},
{text:"클래스",url:"annotated.html",children:[
{text:"클래스 목록",url:"annotated.html"},
{text:"클래스 색인",url:"classes.html"},
{text:"클래스 계통도",url:"inherits.html"},
{text:"클래스 멤버",url:"functions.html",children:[
{text:"모두",url:"functions.html"},
{text:"함수",url:"functions_func.html"},
{text:"변수",url:"functions_vars.html"}]}]},
{text:"파일들",url:"files.html",children:[
{text:"파일 목록",url:"files.html"}]}]}
