var _splash_activity_8java =
[
    [ "com.example.tlqkf.SplashActivity", "classcom_1_1example_1_1tlqkf_1_1_splash_activity.html", "classcom_1_1example_1_1tlqkf_1_1_splash_activity" ]
];